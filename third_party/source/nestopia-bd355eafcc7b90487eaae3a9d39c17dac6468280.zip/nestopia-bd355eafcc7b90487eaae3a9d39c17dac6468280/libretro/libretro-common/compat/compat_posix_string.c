/* Copyright  (C) 2010-2020 The RetroArch team
 *
 * ---------------------------------------------------------------------------------------
 * The following license statement only applies to this file (compat_posix_string.c).
 * ---------------------------------------------------------------------------------------
 *
 * Permission is hereby granted, free of charge,
 * to any person obtaining a copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

#include <ctype.h>

#include <compat/posix_string.h>

#ifdef _WIN32

#undef strcasecmp
#undef strdup
#undef isblank
#undef strtok_r
#include <ctype.h>
#include <stdlib.h>
#include <stddef.h>
#include <compat/strl.h>

#include <string.h>

/* ASCII case folding, not tolower.
 *
 * tolower takes an int that must be representable as unsigned char or
 * EOF.  A plain char sign-extends any byte above 0x7F into a negative
 * value, so passing one straight in is undefined - and these are
 * compared on file paths and user text, where such bytes are ordinary.
 * glibc happens to tolerate it because its table is offset for exactly
 * this mistake; nothing guarantees the next libc will.
 *
 * Folding only A-Z is also what the callers mean.  Anything wider makes
 * a comparison depend on the user's locale, which for extensions,
 * driver names and identifiers is not wanted. */
#define COMPAT_LOWER(c) \
   (((c) >= 'A' && (c) <= 'Z') ? ((c) + ('a' - 'A')) : (c))

int retro_strcasecmp__(const char *a, const char *b)
{
   while (*a && *b)
   {
      int a_ = COMPAT_LOWER((unsigned char)*a);
      int b_ = COMPAT_LOWER((unsigned char)*b);

      if (a_ != b_)
         return a_ - b_;

      a++;
      b++;
   }

   return COMPAT_LOWER((unsigned char)*a) - COMPAT_LOWER((unsigned char)*b);
}

char *retro_strdup__(const char *orig)
{
   size_t _len = strlen(orig) + 1;
   char *ret   = (char*)malloc(_len);
   if (!ret)
      return NULL;
   memcpy(ret, orig, _len);
   return ret;
}

int retro_isblank__(int c)
{
   return (c == ' ') || (c == '\t');
}

char *retro_strtok_r__(char *str, const char *delim, char **saveptr)
{
   char *first = NULL;
   if (!saveptr || !delim)
      return NULL;

   if (str)
      *saveptr = str;

   do
   {
      char *ptr = NULL;
      first = *saveptr;
      while (*first && strchr(delim, *first))
         *first++ = '\0';

      if (*first == '\0')
         return NULL;

      ptr = first + 1;

      while (*ptr && !strchr(delim, *ptr))
         ptr++;

      *saveptr = ptr + (*ptr ? 1 : 0);
      *ptr     = '\0';
   } while (strlen(first) == 0);

   return first;
}
#endif
