////////////////////////////////////////////////////////////////////////////////////////
//
// Nestopia - NES/Famicom emulator written in C++
//
// Copyright (C) 2003-2008 Martin Freij
//
// This file is part of Nestopia.
//
// Nestopia is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// Nestopia is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Nestopia; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
////////////////////////////////////////////////////////////////////////////////////////

#ifndef NST_BOARD_REXSOFT_DB5Z_H
#define NST_BOARD_REXSOFT_DB5Z_H

namespace Nes
{
	namespace Core
	{
		namespace Boards
		{
			namespace RexSoft
			{
				class Dbz5 : public Mmc3
				{
				public:

					explicit Dbz5(const Context& c)
					: Mmc3(c,REV_A) {}

				private:

					void SubReset(bool);
					void SubSave(State::Saver&) const;
					void SubLoad(State::Loader&,dword);

					void NST_FASTCALL UpdateChr(uint,uint) const;

					NES_DECL_PEEK( 4100 );
					NES_DECL_POKE( 4100 );

					uint exReg;
				};
			}
		}
	}
}

#endif
