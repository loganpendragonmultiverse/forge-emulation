//============================================================================
//
//   SSSS    tt          lll  lll       
//  SS  SS   tt           ll   ll        
//  SS     tttttt  eeee   ll   ll   aaaa 
//   SSSS    tt   ee  ee  ll   ll      aa
//      SS   tt   eeeeee  ll   ll   aaaaa  --  "An Atari 2600 VCS Emulator"
//  SS  SS   tt   ee      ll   ll  aa  aa
//   SSSS     ttt  eeeee llll llll  aaaaa
//
// Copyright (c) 1995-2014 by Bradford W. Mott, Stephen Anthony
// and the Stella Team
//
// See the file "License.txt" for information on usage and redistribution of
// this file, and for a DISCLAIMER OF ALL WARRANTIES.
//
// $Id: CartCTY.cxx 2838 2014-01-17 23:34:03Z stephena $
//============================================================================

#include <cstring>

#include "OSystem.hxx"
#include "Serializer.hxx"
#include "System.hxx"
#include "CartCTYTunes.hxx"
#include "CartCTY.hxx"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
CartridgeCTY::CartridgeCTY(const uint8_t* image, uint32_t size, const OSystem& osystem)
  : Cartridge(osystem.settings()),
    myOSystem(osystem),
    myOperationType(0),
    myCounter(0),
    myLDAimmediate(false),
    myRandomNumber(0x2B435044),
    myRamAccessTimeout(0),
    mySystemCycles(0),
    myFractionalClocks(0),
    myDpcClockNum(12000),   // default to NTSC until the console sets the format
    myDpcClockDen(715909)
{
  // Copy the ROM image into my buffer
  memcpy(myImage, image, MIN(32768u, size));
  createCodeAccessBase(32768);

  // This cart contains 64 bytes extended RAM @ 0x1000
  registerRamArea(0x1000, 64, 0x40, 0x00);

  // Point to the first tune
  myFrequencyImage = CartCTYTunes;

  // Remember startup bank (not bank 0, since that's ARM code)
  myStartBank = 1;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
CartridgeCTY::~CartridgeCTY()
{
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void CartridgeCTY::reset()
{
  // Initialize RAM
  if(mySettings.getBool("ramrandom"))
    for(uint32_t i = 0; i < 64; ++i)
      myRAM[i] = mySystem->randGenerator().next();
  else
    memset(myRAM, 0, 64);

  myRAM[0] = myRAM[1] = myRAM[2] = myRAM[3] = 0xFF;

  // Update cycles to the current system cycles
  mySystemCycles = mySystem->cycles();
  myFractionalClocks = 0;

  // Upon reset we switch to the startup bank
  bank(myStartBank);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void CartridgeCTY::systemCyclesReset()
{
  // Adjust the cycle counter so that it reflects the new value
  mySystemCycles -= mySystem->cycles();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void CartridgeCTY::install(System& system)
{
  mySystem     = &system;
  uint16_t shift = mySystem->pageShift();

  // Map all RAM accesses to call peek and poke
  System::PageAccess access(0, 0, 0, this, System::PA_READ);
  for(uint32_t i = 0x1000; i < 0x1080; i += (1 << shift))
    mySystem->setPageAccess(i >> shift, access);

  // Install pages for the startup bank
  bank(myStartBank);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
uint8_t CartridgeCTY::peek(uint16_t address)
{
  uint16_t peekAddress = address;
  address &= 0x0FFF;
  uint8_t peekValue = myImage[myCurrentBank + address];

  // In debugger/bank-locked mode, we ignore all hotspots and in general
  // anything that can change the internal state of the cart
  if(bankLocked())
    return peekValue;

  // Check for aliasing to 'LDA #$F2'
  if(myLDAimmediate && peekValue == 0xF2)
  {
    myLDAimmediate = false;

    // Update the music data fetchers (counter & flag)
    updateMusicModeDataFetchers();

#if 0
    // using myDisplayImage[] instead of myProgramImage[] because waveforms
    // can be modified during runtime.
    uint32_t i = myDisplayImage[(myMusicWaveforms[0] << 5) + (myMusicCounters[0] >> 27)] +
               myDisplayImage[(myMusicWaveforms[1] << 5) + (myMusicCounters[1] >> 27)] +
               myDisplayImage[(myMusicWaveforms[2] << 5) + (myMusicCounters[2] >> 27)];
    return = (uint8_t)i;
#endif
    return 0xF2;  // FIXME - return frequency value here
  }
  else
    myLDAimmediate = false;

  if(address < 0x0040)  // Write port is at $1000 - $103F (64 bytes)
  {
    // Reading from the write port triggers an unwanted write
    uint8_t value = mySystem->getDataBusState(0xFF);

    if(bankLocked())
      return value;
    else
    {
      triggerReadFromWritePort(peekAddress);
      return myRAM[address] = value;
    }
  }
  else if(address < 0x0080)  // Read port is at $1040 - $107F (64 bytes)
  {
    address -= 0x40;
    switch(address)
    {
      case 0x00:  // Error code after operation
        return myRAM[0];
      case 0x01:  // Get next Random Number (8-bit LFSR)
        myRandomNumber = ((myRandomNumber & (1<<10)) ? 0x10adab1e: 0x00) ^
                         ((myRandomNumber >> 11) | (myRandomNumber << 21));
        return myRandomNumber & 0xFF;
      case 0x02:  // Get Tune position (low byte)
        return myCounter & 0xFF;
      case 0x03:  // Get Tune position (high byte)
        return (myCounter >> 8) & 0xFF;
      default:
        return myRAM[address];
    }
  }
  else  // Check hotspots
  {
    switch(address)
    {
      case 0x0FF4:
        // Bank 0 is ARM code and not actually accessed
        return ramReadWrite();
      case 0x0FF5:
      case 0x0FF6:
      case 0x0FF7:
      case 0x0FF8:
      case 0x0FF9:
      case 0x0FFA:
      case 0x0FFB:
        // Banks 1 through 7
        bank(address - 0x0FF4);
        break;
      default:
        break;
    }

    // Is this instruction an immediate mode LDA?
    myLDAimmediate = (peekValue == 0xA9);

    return peekValue;
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
bool CartridgeCTY::poke(uint16_t address, uint8_t value)
{
  address &= 0x0FFF;

  if(address < 0x0040)  // Write port is at $1000 - $103F (64 bytes)
  {
    switch(address)  // FIXME for functionality
    {
      case 0x00:  // Operation type for $1FF4
        myOperationType = value;
        break;
      case 0x01:  // Set Random seed value (reset)
        myRandomNumber = 0x2B435044;
        break;
      case 0x02:  // Reset fetcher to beginning of tune
        myCounter = 0;
        break;
      case 0x03:  // Advance fetcher to next tune position
        myCounter = (myCounter + 3) & 0x0fff;
        break;
      default:
        myRAM[address] = value;
        break;
    }
  }
  else  // Check hotspots
  {
    switch(address)
    {
      case 0x0FF4:
        // Bank 0 is ARM code and not actually accessed
        ramReadWrite();
        break;
      case 0x0FF5:
      case 0x0FF6:
      case 0x0FF7:
      case 0x0FF8:
      case 0x0FF9:
      case 0x0FFA:
      case 0x0FFB:
        // Banks 1 through 7
        bank(address - 0x0FF4);
        break;
      default:
        break;
    }
  }
  return false;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
bool CartridgeCTY::bank(uint16_t bank)
{ 
  if(bankLocked()) return false;

  // Remember what bank we're in
  myCurrentBank = bank << 12;
  uint16_t shift = mySystem->pageShift();

  // Setup the page access methods for the current bank
  System::PageAccess access(0, 0, 0, this, System::PA_READ);
  for(uint32_t address = 0x1080; address < 0x2000; address += (1 << shift))
  {
    access.codeAccessBase = &myCodeAccessBase[myCurrentBank + (address & 0x0FFF)];
    mySystem->setPageAccess(address >> shift, access);
  }
  return myBankChanged = true;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
uint16_t CartridgeCTY::bank() const
{
  return myCurrentBank >> 12;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
uint16_t CartridgeCTY::bankCount() const
{
  return 8;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
bool CartridgeCTY::patch(uint16_t address, uint8_t value)
{
  address &= 0x0FFF;

  if(address < 0x0080)
  {
    // Normally, a write to the read port won't do anything
    // However, the patch command is special in that ignores such
    // cart restrictions
    myRAM[address & 0x003F] = value;
  }
  else
    myImage[myCurrentBank + address] = value;

  return myBankChanged = true;
} 

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
const uint8_t* CartridgeCTY::getImage(int& size) const
{
  size = 32768;
  return myImage;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
bool CartridgeCTY::save(Serializer& out) const
{
   out.putString(name());
   out.putShort(bank());
   out.putByteArray(myRAM, 64);

   out.putByte(myOperationType);
   out.putShort(myCounter);
   out.putBool(myLDAimmediate);
   out.putInt(myRandomNumber);
   out.putInt(mySystemCycles);
   out.putInt(myFractionalClocks);

   return true;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
bool CartridgeCTY::load(Serializer& in)
{
   if(in.getString() != name())
      return false;

   // Remember what bank we were in
   bank(in.getShort());
   in.getByteArray(myRAM, 64);

   myOperationType = in.getByte();
   myCounter = in.getShort();
   myLDAimmediate = in.getBool();
   myRandomNumber = in.getInt();
   mySystemCycles = (int32_t)in.getInt();
   myFractionalClocks = in.getInt();

   return true;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void CartridgeCTY::setRomName(const string& name)
{
  myEEPROMFile = myOSystem.nvramDir() + name + "_eeprom.dat";
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
uint8_t CartridgeCTY::ramReadWrite()
{
  /* The following algorithm implements accessing Harmony cart EEPROM

    1. Wait for an access to hotspot location $1FF4 (return 1 in bit 6
       while busy).

    2. Determine operation from myOperationType.

    3. Save or load relevant EEPROM memory to/from a file.

    4. Set byte 0 of RAM+ memory to zero to indicate success (will
       always happen in emulation).

    5. Return 0 (in bit 6) on the next access to $1FF4, if enough time has
       passed to complete the operation on a real system (0.5 s for read,
       1 s for write).
  */

  if(bankLocked()) return 0xff;

  // First access sets the timer
  if(myRamAccessTimeout == 0)
  {
    // Opcode and value in form of XXXXYYYY (from myOperationType), where:
    //    XXXX = index and YYYY = operation
    uint8_t index = myOperationType >> 4;
    switch(myOperationType & 0xf)
    {
      case 1:  // Load tune (index = tune)
        if(index < 7)
        {
          // 0.5 s read delay, as emulated 6507 cycles (NTSC ~1.19 MHz):
          //   0.5 s -> 596591 cycles. Deterministic and host-independent.
          myRamAccessTimeout = mySystem->cycles() + 596591;
          loadTune(index);
        }
        break;
      case 2:  // Load score table (index = table)
        if(index < 4)
        {
          // Add 0.5 s delay for read
          myRamAccessTimeout = mySystem->cycles() + 596591;
          loadScore(index);
        }
        break;
      case 3:  // Save score table (index = table)
        if(index < 4)
        {
          // 1 s write delay -> 1193182 cycles
          myRamAccessTimeout = mySystem->cycles() + 1193182;
          saveScore(index);
        }
        break;
      case 4:  // Wipe all score tables
        // Add 1 s delay for write
        myRamAccessTimeout = mySystem->cycles() + 1193182;
        wipeAllScores();
        break;
    }
    // keep 0 reserved as the "idle" sentinel across the cycle-counter wrap
    if(myRamAccessTimeout == 0)
      myRamAccessTimeout = 1;
    // Bit 6 is 1, busy
    return myImage[myCurrentBank + 0xFF4] | 0x40;
  }
  else
  {
    // Have we reached the timeout value yet? Signed difference so the
    // comparison is correct even across the 32-bit cycle-counter wrap.
    if((int32_t)((uint32_t)mySystem->cycles() - (uint32_t)myRamAccessTimeout) >= 0)
    {
      myRamAccessTimeout = 0;  // Turn off timer
      myRAM[0] = 0;            // Successful operation

      // Bit 6 is 0, ready/success
      return myImage[myCurrentBank + 0xFF4] & ~0x40;
    }
    else
      // Bit 6 is 1, busy
      return myImage[myCurrentBank + 0xFF4] | 0x40;
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void CartridgeCTY::loadTune(uint8_t index)
{
  // Each tune is offset by 4096 bytes
  // Instead of copying non-modifiable data around (as would happen on the
  // Harmony), we simply point to the appropriate tune
  myFrequencyImage = CartCTYTunes + (index << 12);

  // Reset to beginning of tune
  myCounter = 0;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void CartridgeCTY::loadScore(uint8_t index)
{
  Serializer serializer(myEEPROMFile, true);
  if(serializer.isValid())
  {
    uint8_t scoreRAM[256];
    serializer.getByteArray(scoreRAM, 256);
    // Grab 60B slice @ given index (first 4 bytes are ignored)
    memcpy(myRAM+4, scoreRAM + (index << 6) + 4, 60);
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void CartridgeCTY::saveScore(uint8_t index)
{
  Serializer serializer(myEEPROMFile);
  if(serializer.isValid())
  {
    // Load score RAM
    uint8_t scoreRAM[256];
    serializer.getByteArray(scoreRAM, 256);

    // Add 60B RAM to score table @ given index (first 4 bytes are ignored)
    memcpy(scoreRAM + (index << 6) + 4, myRAM+4, 60);

    // Save score RAM
    serializer.reset();
    serializer.putByteArray(scoreRAM, 256);
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void CartridgeCTY::wipeAllScores()
{
  Serializer serializer(myEEPROMFile);
  if(serializer.isValid())
  {
    // Erase score RAM
    uint8_t scoreRAM[256];
    memset(scoreRAM, 0, 256);
    serializer.putByteArray(scoreRAM, 256);
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
inline void CartridgeCTY::updateMusicModeDataFetchers()
{
  // Calculate the number of cycles since the last update
  int32_t cycles = mySystem->cycles() - mySystemCycles;
  mySystemCycles = mySystem->cycles();

  // Calculate the number of DPC OSC clocks since the last update
  // The DPC music oscillator is an on-chip RC circuit (560K ohm resistor,
  // 5% tolerance, plus an on-die capacitor), so its frequency varies from
  // cartridge to cartridge; ~20 KHz is the accepted nominal model (Stella
  // uses 20 KHz, UnoCart uses 21 KHz on real hardware). Against the NTSC
  // CPU clock of 3579545/3 Hz this is exactly 20000/(3579545/3) =
  // OSC clocks per CPU cycle as the exact rational myDpcClockNum/Den,
  // selected from the console's TV format (NTSC 12000/715909, PAL
  // 10000/591149, SECAM 8/475). The fraction is carried as an integer
  // remainder (units of 1/den clock) so the arithmetic is
  // exact and bit-for-bit deterministic on every platform.
  uint64_t acc = (uint64_t)(uint32_t)cycles * myDpcClockNum + myFractionalClocks;
  int32_t wholeClocks = (int32_t)(acc / myDpcClockDen);
  myFractionalClocks = (uint32_t)(acc % myDpcClockDen);

  if(wholeClocks <= 0)
    return;

  // Let's update counters and flags of the music mode data fetchers
  for(int x = 0; x <= 2; ++x)
  {
//    myMusicCounters[x] += myMusicFrequencies[x];
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void CartridgeCTY::setDpcClockRate(uint32_t num, uint32_t den)
{
  if(den != 0)
  {
    myDpcClockNum = num;
    myDpcClockDen = den;
  }
}
